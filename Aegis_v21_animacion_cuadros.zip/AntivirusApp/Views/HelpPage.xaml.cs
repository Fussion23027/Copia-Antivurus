using AntivirusApp.Helpers;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;

namespace AntivirusApp.Views;

/// <summary>Guía de uso: qué hace cada módulo y dónde queda todo.</summary>
public sealed partial class HelpPage : Page
{
    public HelpPage()
    {
        InitializeComponent();

        Loaded += (_, _) =>
        {
            Anim.FadeIn(PageRoot);
            Anim.FadeIn(HeroCard, 40);
        };
    }
}
