using System;
using AntivirusApp.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;

namespace AntivirusApp.Views;

/// <summary>Acceso local: usuario y contraseña (AuthService).</summary>
public sealed partial class LoginPage : Page
{
    public LoginPage()
    {
        InitializeComponent();

        UserBox.Text = "admin";
        EnterButton.Click += (_, _) => Submit();
        PassBox.KeyDown += OnKeyDown;
        Loaded += (_, _) =>
        {
            Helpers.Anim.FadeIn(PageRoot);
            Helpers.Anim.Pop(LogoBox);
            PassBox.Focus(FocusState.Programmatic);
        };
    }

    private void OnKeyDown(object sender, KeyRoutedEventArgs e)
    {
        if (e.Key == Windows.System.VirtualKey.Enter) Submit();
    }

    private void Submit()
    {
        string user = (UserBox.Text ?? string.Empty).Trim();
        string password = PassBox.Password ?? string.Empty;

        if (!AuthService.Validate(user, password))
        {
            ErrorText.Text = "Usuario o contraseña incorrectos. Prueba con admin / aegis.";
            ErrorText.Visibility = Visibility.Visible;
            return;
        }

        ErrorText.Visibility = Visibility.Collapsed;
        AuthService.CurrentUser = user;
        App.Log("Login correcto: " + user);

        Frame.Navigate(typeof(ShellPage));
    }
}
