using System;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Animation;

namespace AntivirusApp.Helpers;

/// <summary>Animaciones ligeras de entrada (fundido + pequeño desplazamiento).</summary>
public static class Anim
{
    public static void FadeIn(FrameworkElement element, int delayMs = 0, double from = 0.0)
    {
        try
        {
            element.Opacity = from;

            var storyboard = new Storyboard();
            var fade = new DoubleAnimation
            {
                From = from,
                To = 1,
                Duration = new Duration(TimeSpan.FromMilliseconds(280)),
                BeginTime = TimeSpan.FromMilliseconds(delayMs),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };

            Storyboard.SetTarget(fade, element);
            Storyboard.SetTargetProperty(fade, "Opacity");
            storyboard.Children.Add(fade);
            storyboard.Begin();
        }
        catch (Exception)
        {
            element.Opacity = 1;
        }
    }

    /// <summary>Animación de "pop" para círculos y avatares (escala con rebote).</summary>
    public static void Pop(FrameworkElement element)
    {
        try
        {
            var scale = new ScaleTransform { ScaleX = 0.86, ScaleY = 0.86 };
            element.RenderTransformOrigin = new Windows.Foundation.Point(0.5, 0.5);
            element.RenderTransform = scale;

            var storyboard = new Storyboard();

            foreach (var property in new[] { "ScaleX", "ScaleY" })
            {
                var animation = new DoubleAnimation
                {
                    From = 0.86,
                    To = 1,
                    Duration = new Duration(TimeSpan.FromMilliseconds(380)),
                    EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.55 }
                };

                Storyboard.SetTarget(animation, scale);
                Storyboard.SetTargetProperty(animation, property);
                storyboard.Children.Add(animation);
            }

            storyboard.Begin();
        }
        catch (Exception)
        {
            element.RenderTransform = null;
        }
    }

    /// <summary>Escala suave al pasar el ratón por encima.</summary>
    public static void HoverScale(FrameworkElement element, double grow = 1.08)
    {
        try
        {
            var scale = new ScaleTransform { ScaleX = 1, ScaleY = 1 };
            element.RenderTransformOrigin = new Windows.Foundation.Point(0.5, 0.5);
            element.RenderTransform = scale;

            void To(double target)
            {
                var storyboard = new Storyboard();

                foreach (var property in new[] { "ScaleX", "ScaleY" })
                {
                    var animation = new DoubleAnimation
                    {
                        To = target,
                        Duration = new Duration(TimeSpan.FromMilliseconds(160)),
                        EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
                    };

                    Storyboard.SetTarget(animation, scale);
                    Storyboard.SetTargetProperty(animation, property);
                    storyboard.Children.Add(animation);
                }

                storyboard.Begin();
            }

            element.PointerEntered += (_, _) => To(grow);
            element.PointerExited += (_, _) => To(1);
        }
        catch (Exception)
        {
            element.RenderTransform = null;
        }
    }

    public static void PopIn(FrameworkElement element, int delayMs = 0)
    {
        try
        {
            element.Opacity = 0;

            var storyboard = new Storyboard();
            var fade = new DoubleAnimation
            {
                From = 0,
                To = 1,
                Duration = new Duration(TimeSpan.FromMilliseconds(200)),
                BeginTime = TimeSpan.FromMilliseconds(delayMs),
                EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.4 }
            };

            Storyboard.SetTarget(fade, element);
            Storyboard.SetTargetProperty(fade, "Opacity");
            storyboard.Children.Add(fade);
            storyboard.Begin();
        }
        catch (Exception)
        {
            element.Opacity = 1;
        }
    }
}
