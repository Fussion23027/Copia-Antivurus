using System;
using System.Collections.Generic;

namespace AntivirusApp.Models;

/// <summary>
/// Opciones del Clenaer. A diferencia del motor heurístico no analiza contenido:
/// mide peso en disco, que es lo que el usuario necesita para liberar espacio.
/// </summary>
public sealed class CleanerOptions
{
    public CleanerOptions(IReadOnlyList<string> roots) => Roots = roots;

    /// <summary>Unidades o carpetas que se recorren.</summary>
    public IReadOnlyList<string> Roots { get; }

    /// <summary>Tamaño mínimo para que un archivo aparezca en la lista.</summary>
    public long MinFileBytes { get; set; } = 50L * 1024 * 1024;

    /// <summary>Tamaño mínimo para que una carpeta aparezca en la lista.</summary>
    public long MinFolderBytes { get; set; } = 120L * 1024 * 1024;

    /// <summary>No entra en Windows, System32, WinSxS, $Recycle.Bin… ni en /proc, /sys.</summary>
    public bool SkipSystem { get; set; } = true;

    /// <summary>Incluye archivos ocultos y de sistema.</summary>
    public bool IncludeHidden { get; set; }

    /// <summary>Cuántos archivos pesados se conservan al final (los más grandes).</summary>
    public int MaxFiles { get; set; } = 600;
}

/// <summary>
/// Contadores en vivo. La vista los lee con un temporizador del DispatcherQueue
/// mientras el escaneo corre en un hilo de fondo, sin bloquear la interfaz.
/// </summary>
public sealed class CleanerCounters
{
    public long Files;
    public long Dirs;
    public long Bytes;
    public long Skipped;
    public long Errors;
    public string Current = string.Empty;
    public bool Running;
    public bool Done;
    public string? Error;
}

/// <summary>Archivo o carpeta pesada (misma forma para pintar una sola lista).</summary>
public sealed class CleanerItem
{
    public string Path = string.Empty;
    public string Name = string.Empty;
    public string Directory = string.Empty;
    public long Size;
    public int Files;
    public DateTime Modified;
    public bool IsFolder;
    public string Kind = "otro";
}

public sealed class CleanerScanResult
{
    public List<CleanerItem> Files { get; } = new();

    public List<CleanerItem> Folders { get; } = new();
}

/// <summary>Peso real de una aplicación instalada.</summary>
public sealed class AppUsage
{
    public string Name = string.Empty;
    public string Path = string.Empty;
    public string Group = string.Empty;
    public long Size;
    public int Files;
    public DateTime Newest;
    public DateTime Oldest;
}

/// <summary>Resultado de enviar elementos a la papelera de reciclaje.</summary>
public sealed class TrashResult
{
    public List<string> Moved { get; } = new();

    public List<string> Failed { get; } = new();

    public long Freed;

    public bool Ok => Moved.Count > 0;
}
