namespace AntivirusApp.Models;

/// <summary>
/// Veredictos posibles. Son cadenas (no enum) porque la vista los compara
/// directamente con los filtros de los chips: "M", "S" y "all".
/// </summary>
public static class Verdicts
{
    public const string Malicious = "M";

    public const string Suspicious = "S";

    public const string Clean = "C";

    public const string Error = "E";
}
