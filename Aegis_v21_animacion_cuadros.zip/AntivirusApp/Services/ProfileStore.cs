using System;
using System.IO;
using System.Text.Json;

namespace AntivirusApp.Services;

/// <summary>Datos de la cuenta que el usuario puede editar.</summary>
public sealed class UserProfile
{
    public string DisplayName { get; set; } = "";
    public string Description { get; set; } = "";
    public string AvatarPath { get; set; } = "";
}

/// <summary>
/// Perfil local del usuario: nombre visible, descripción y foto.
/// Se guarda en %LocalAppData%\Aegis\profile.json y la foto se copia a
/// %LocalAppData%\Aegis\avatar.* para que no dependa del archivo original.
/// </summary>
public static class ProfileStore
{
    public static string Folder => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "Aegis");

    public static string AvatarFile => Path.Combine(Folder, "avatar.png");

    private static string File_ => Path.Combine(Folder, "profile.json");

    public static event Action? Changed;

    public static UserProfile Load()
    {
        try
        {
            if (!File.Exists(File_)) return new UserProfile();

            var profile = JsonSerializer.Deserialize<UserProfile>(File.ReadAllText(File_));
            if (profile is null) return new UserProfile();

            if (!string.IsNullOrWhiteSpace(profile.AvatarPath) && !File.Exists(profile.AvatarPath))
                profile.AvatarPath = "";

            return profile;
        }
        catch (Exception ex)
        {
            App.Log("ProfileStore.Load FALLÓ", ex);
            return new UserProfile();
        }
    }

    public static void Save(UserProfile profile)
    {
        try
        {
            Directory.CreateDirectory(Folder);

            File.WriteAllText(File_, JsonSerializer.Serialize(profile, new JsonSerializerOptions
            {
                WriteIndented = true
            }));

            Changed?.Invoke();
        }
        catch (Exception ex)
        {
            App.Log("ProfileStore.Save FALLÓ", ex);
        }
    }

    /// <summary>Copia la imagen elegida al perfil y devuelve la ruta definitiva.</summary>
    public static string SetAvatar(string sourcePath)
    {
        Directory.CreateDirectory(Folder);
        File.Copy(sourcePath, AvatarFile, true);
        return AvatarFile;
    }

    public static void ClearAvatar()
    {
        try
        {
            if (File.Exists(AvatarFile)) File.Delete(AvatarFile);
        }
        catch (Exception ex)
        {
            App.Log("ProfileStore.ClearAvatar FALLÓ", ex);
        }
    }

    /// <summary>Iniciales para el avatar cuando no hay foto.</summary>
    public static string Initials(string? name)
    {
        string value = (name ?? string.Empty).Trim();
        if (value.Length == 0) return "AE";

        var parts = value.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length == 1)
            return parts[0].Length >= 2 ? parts[0].Substring(0, 2).ToUpperInvariant() : parts[0].ToUpperInvariant();

        return (parts[0].Substring(0, 1) + parts[1].Substring(0, 1)).ToUpperInvariant();
    }
}
